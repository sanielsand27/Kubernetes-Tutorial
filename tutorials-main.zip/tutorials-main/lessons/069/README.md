# How to Create GKE Cluster Using TERRAFORM from Scratch?

[YouTube Tutorial](https://youtu.be/XTcos7s0iDo)

## Set Up Default Credentials
```bash
gcloud auth application-default login
```
