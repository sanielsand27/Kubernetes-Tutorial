# How to Deploy React App to GitHub Pages?

[YouTube Tutorial](https://antonputra.com/how-to-deploy-create-react-app-to-github-pages/)