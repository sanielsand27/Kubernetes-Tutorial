# How to Create Lambda Container Images?

[YouTube Tutorial](https://antonputra.com/how-to-create-lambda-container-images/)
