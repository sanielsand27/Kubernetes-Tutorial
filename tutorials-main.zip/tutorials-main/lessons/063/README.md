# Terraform Blue Green Deployment & Terraform Canary Deployment 🔵🐣🟢 AWS | ALB | EC2

[Step by Step Tutorial](https://youtu.be/6Pw6GabncRo)
