# Kubernetes Persistent Volumes NFS (AWS | EKS | EFS Storage Class | EFS Provisioner | ReadWriteMany)

## Create EKS Cluster
```bash
$ eksctl create cluster -f cluster.yaml
```

## Delete EKS Cluster
```bash
$ eksctl delete cluster -f cluster.yaml
```